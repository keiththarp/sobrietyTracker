# Sobriety Tracker
Simple sobriety tracker that accepts sober date and average daily spend on drinking and calculates time and money saved in sobriety
